# Official objects for OpenRCT2
Contains objects from RollerCoaster Tycoon 1, RollerCoaster Tycoon 2 and their expansion packs.
For the main development and codebase of OpenRCT2, visit [OpenRCT2/OpenRCT2](https://github.com/OpenRCT2/OpenRCT2).

### Build Status
![Build Status](https://github.com/OpenRCT2/objects/workflows/CI/badge.svg)
